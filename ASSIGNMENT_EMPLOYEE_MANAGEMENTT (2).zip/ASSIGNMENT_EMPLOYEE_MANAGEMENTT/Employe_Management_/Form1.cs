﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Employe_Management_
{
    public partial class Form1 : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\EmployeeManagement.mdf;Integrated Security=True";
        // Connection string pointing to MDF file
        public Form1()
        {
            InitializeComponent();
            LoadEmployees();
        }
        

        private void LoadEmployees()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Id, Name, Age, Department, Salary FROM Employees ORDER BY Name";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    Employee_dgv.DataSource = dataTable;
                    Employee_dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading employees: " + ex.Message, "Database Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            // Validate input fields
            if (string.IsNullOrWhiteSpace(Name_txt.Text))
            {
                MessageBox.Show("Please enter employee name.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Name_txt.Focus();
                return;
            }

            if (!int.TryParse(Age_txt.Text, out int age))
            {
                MessageBox.Show("Please enter a valid age.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Age_txt.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Dep_txt.Text))
            {
                MessageBox.Show("Please enter department.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Dep_txt.Focus();
                return;
            }

            if (!int.TryParse(Salary_.Text, out int salary))
            {
                MessageBox.Show("Please enter a valid salary.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Salary_.Focus();
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Employees (Name, Age, Department, Salary) VALUES (@Name, @Age, @Department, @Salary)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", Name_txt.Text.Trim());
                        command.Parameters.AddWithValue("@Age", age);
                        command.Parameters.AddWithValue("@Department", Dep_txt.Text.Trim());
                        command.Parameters.AddWithValue("@Salary", salary);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Employee added successfully!", "Success",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearInputs();
                            LoadEmployees();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding employee: " + ex.Message, "Database Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Edit_Click(object sender, EventArgs e)
        {
            if (Employee_dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an employee to edit.", "Selection Required",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow row = Employee_dgv.SelectedRows[0];
            Name_txt.Text = row.Cells["Name"].Value?.ToString() ?? "";
            Age_txt.Text = row.Cells["Age"].Value?.ToString() ?? "";
            Dep_txt.Text = row.Cells["Department"].Value?.ToString() ?? "";
            Salary_.Text = row.Cells["Salary"].Value?.ToString() ?? "";
        }

        private void Save_Click(object sender, EventArgs e)
        {
            if (Employee_dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an employee to update.", "Selection Required",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validate input fields
            if (string.IsNullOrWhiteSpace(Name_txt.Text))
            {
                MessageBox.Show("Please enter employee name.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Name_txt.Focus();
                return;
            }

            if (!int.TryParse(Age_txt.Text, out int age))
            {
                MessageBox.Show("Please enter a valid age.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Age_txt.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Dep_txt.Text))
            {
                MessageBox.Show("Please enter department.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Dep_txt.Focus();
                return;
            }

            if (!int.TryParse(Salary_.Text, out int salary))
            {
                MessageBox.Show("Please enter a valid salary.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Salary_.Focus();
                return;
            }

            try
            {
                int employeeId = Convert.ToInt32(Employee_dgv.SelectedRows[0].Cells["Id"].Value);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE Employees SET Name=@Name, Age=@Age, Department=@Department, Salary=@Salary WHERE Id=@Id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", Name_txt.Text.Trim());
                        command.Parameters.AddWithValue("@Age", age);
                        command.Parameters.AddWithValue("@Department", Dep_txt.Text.Trim());
                        command.Parameters.AddWithValue("@Salary", salary);
                        command.Parameters.AddWithValue("@Id", employeeId);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Employee updated successfully!", "Success",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearInputs();
                            LoadEmployees();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating employee: " + ex.Message, "Database Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Delet_Click(object sender, EventArgs e)
        {
            if (Employee_dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an employee to delete.", "Selection Required",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this employee?",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    int employeeId = Convert.ToInt32(Employee_dgv.SelectedRows[0].Cells["Id"].Value);

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM Employees WHERE Id=@Id";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Id", employeeId);

                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Employee deleted successfully!", "Success",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ClearInputs();
                                LoadEmployees();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting employee: " + ex.Message, "Database Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Cancle_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void Exit___Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ClearInputs()
        {
            Name_txt.Text = "";
            Age_txt.Text = "";
            Dep_txt.Text = "";
            Salary_.Text = "";
            Name_txt.Focus();
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void Salary__TextChanged(object sender, EventArgs e) { }
    }
}