﻿namespace Employe_Management_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

         
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Name_txt = new System.Windows.Forms.TextBox();
            this.Age_txt = new System.Windows.Forms.TextBox();
            this.Dep_txt = new System.Windows.Forms.TextBox();
            this.Add = new System.Windows.Forms.Button();
            this.Delet = new System.Windows.Forms.Button();
            this.Edit = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.Cancle = new System.Windows.Forms.Button();
            this.Employee_dgv = new System.Windows.Forms.DataGridView();
            this.list_eployee = new System.Windows.Forms.GroupBox();
            this.Exit__ = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Salary_ = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Employee_dgv)).BeginInit();
            this.list_eployee.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(148, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = " Employee Management Application  ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(148, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(157, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Age:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(121, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Department:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // Name_txt
            // 
            this.Name_txt.Location = new System.Drawing.Point(207, 92);
            this.Name_txt.Name = "Name_txt";
            this.Name_txt.Size = new System.Drawing.Size(81, 20);
            this.Name_txt.TabIndex = 4;
            // 
            // Age_txt
            // 
            this.Age_txt.Location = new System.Drawing.Point(207, 128);
            this.Age_txt.Name = "Age_txt";
            this.Age_txt.Size = new System.Drawing.Size(81, 20);
            this.Age_txt.TabIndex = 5;
            // 
            // Dep_txt
            // 
            this.Dep_txt.Location = new System.Drawing.Point(207, 166);
            this.Dep_txt.Name = "Dep_txt";
            this.Dep_txt.Size = new System.Drawing.Size(81, 20);
            this.Dep_txt.TabIndex = 6;
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(34, 229);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(110, 37);
            this.Add.TabIndex = 7;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Delet
            // 
            this.Delet.Location = new System.Drawing.Point(325, 229);
            this.Delet.Name = "Delet";
            this.Delet.Size = new System.Drawing.Size(110, 37);
            this.Delet.TabIndex = 8;
            this.Delet.Text = "Delet";
            this.Delet.UseVisualStyleBackColor = true;
            this.Delet.Click += new System.EventHandler(this.Delet_Click);
            // 
            // Edit
            // 
            this.Edit.Location = new System.Drawing.Point(178, 229);
            this.Edit.Name = "Edit";
            this.Edit.Size = new System.Drawing.Size(110, 37);
            this.Edit.TabIndex = 9;
            this.Edit.Text = "Edit";
            this.Edit.UseVisualStyleBackColor = true;
            this.Edit.Click += new System.EventHandler(this.Edit_Click);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(85, 272);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(110, 37);
            this.Save.TabIndex = 10;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // Cancle
            // 
            this.Cancle.Location = new System.Drawing.Point(281, 272);
            this.Cancle.Name = "Cancle";
            this.Cancle.Size = new System.Drawing.Size(110, 37);
            this.Cancle.TabIndex = 11;
            this.Cancle.Text = "Cancle";
            this.Cancle.UseVisualStyleBackColor = true;
            this.Cancle.Click += new System.EventHandler(this.Cancle_Click);
            // 
            // Employee_dgv
            // 
            this.Employee_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Employee_dgv.Location = new System.Drawing.Point(32, 36);
            this.Employee_dgv.Name = "Employee_dgv";
            this.Employee_dgv.Size = new System.Drawing.Size(401, 139);
            this.Employee_dgv.TabIndex = 12;
            // 
            // list_eployee
            // 
            this.list_eployee.Controls.Add(this.Employee_dgv);
            this.list_eployee.Location = new System.Drawing.Point(24, 367);
            this.list_eployee.Name = "list_eployee";
            this.list_eployee.Size = new System.Drawing.Size(466, 192);
            this.list_eployee.TabIndex = 13;
            this.list_eployee.TabStop = false;
            this.list_eployee.Text = "List Of Employee";
            // 
            // Exit__
            // 
            this.Exit__.Location = new System.Drawing.Point(178, 324);
            this.Exit__.Name = "Exit__";
            this.Exit__.Size = new System.Drawing.Size(110, 37);
            this.Exit__.TabIndex = 14;
            this.Exit__.Text = "Exit";
            this.Exit__.UseVisualStyleBackColor = true;
            this.Exit__.Click += new System.EventHandler(this.Exit___Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(147, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Salary:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // Salary_
            // 
            this.Salary_.Location = new System.Drawing.Point(207, 200);
            this.Salary_.Name = "Salary_";
            this.Salary_.Size = new System.Drawing.Size(81, 20);
            this.Salary_.TabIndex = 16;
            this.Salary_.TextChanged += new System.EventHandler(this.Salary__TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 589);
            this.Controls.Add(this.Salary_);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Exit__);
            this.Controls.Add(this.list_eployee);
            this.Controls.Add(this.Cancle);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.Edit);
            this.Controls.Add(this.Delet);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Dep_txt);
            this.Controls.Add(this.Age_txt);
            this.Controls.Add(this.Name_txt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Employee_dgv)).EndInit();
            this.list_eployee.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Name_txt;
        private System.Windows.Forms.TextBox Age_txt;
        private System.Windows.Forms.TextBox Dep_txt;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Delet;
        private System.Windows.Forms.Button Edit;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button Cancle;
        private System.Windows.Forms.DataGridView Employee_dgv;
        private System.Windows.Forms.GroupBox list_eployee;
        private System.Windows.Forms.Button Exit__;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Salary_;
    }
}

